#!/usr/bin/env bash
# Apply packages/db/migrations/*.sql in numeric order against DATABASE_URL.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MIG_DIR="$ROOT/packages/db/migrations"

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "DATABASE_URL is required" >&2
  exit 1
fi

if ! command -v psql >/dev/null 2>&1; then
  echo "psql not found — install PostgreSQL client tools" >&2
  exit 1
fi

shopt -s nullglob
files=("$MIG_DIR"/[0-9][0-9][0-9]_*.sql)
if [[ ${#files[@]} -eq 0 ]]; then
  echo "No migration files in $MIG_DIR" >&2
  exit 1
fi

for f in "${files[@]}"; do
  echo "→ applying $(basename "$f")"
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$f"
done
echo "All migrations applied."
