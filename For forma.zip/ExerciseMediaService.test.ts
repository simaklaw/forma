jest.mock('expo-file-system', () => ({
  cacheDirectory: '/mock-cache/',
  getInfoAsync: jest.fn(),
  makeDirectoryAsync: jest.fn(),
  downloadAsync: jest.fn(),
  deleteAsync: jest.fn(),
  readDirectoryAsync: jest.fn()
}));

import * as FileSystem from 'expo-file-system';
import { ExerciseMediaService } from './ExerciseMediaService';

describe('ExerciseMediaService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns the bundled asset number when mediaKey has one, without touching the filesystem', async () => {
    const src = await ExerciseMediaService.getPlaybackSource('lib-pushup', 'pushup');
    expect(typeof src).toBe('number');
    expect(FileSystem.getInfoAsync).not.toHaveBeenCalled();
  });

  it('returns a cached file uri when the cache already has it', async () => {
    (FileSystem.getInfoAsync as jest.Mock)
      .mockResolvedValueOnce({ exists: true }) // ensureCacheDir
      .mockResolvedValueOnce({ exists: true }); // cache file check
    const src = await ExerciseMediaService.getPlaybackSource('lib-some-exercise');
    expect(src).toMatchObject({ uri: expect.stringContaining('lib-some-exercise.mp4') });
  });

  it('returns null when no bundled asset, no cache, and no manifest entry exists', async () => {
    (FileSystem.getInfoAsync as jest.Mock).mockResolvedValue({ exists: false });
    const src = await ExerciseMediaService.getPlaybackSource('lib-totally-unknown-id');
    expect(src).toBeNull();
  });
});
