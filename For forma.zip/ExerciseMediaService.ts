/**
 * ExerciseMediaService — three-tier media resolution:
 * 1. Bundled asset (apps/mobile/assets/exercises/, 12 core exercises)
 * 2. Local disk cache (FileSystem.cacheDirectory, LRU-evicted)
 * 3. Remote URL (direct playback while background download completes)
 *
 * Mirrors the pattern already established in RestTimerEngine.ts (static
 * class, no React dependency) — this is a data-layer service, not a hook.
 */
import * as FileSystem from 'expo-file-system';
import { EXERCISE_VIDEOS, type ExerciseMediaKey } from './exerciseMedia';
import { EXERCISE_VIDEO_MANIFEST } from './exerciseVideoManifest.generated';

const CACHE_DIR = `${FileSystem.cacheDirectory ?? ''}exercise_media/`;
const MAX_CACHE_BYTES = 1024 * 1024 * 1024; // 1 GB

interface CacheEntry {
  path: string;
  sizeBytes: number;
  lastAccessedMs: number;
}

export class ExerciseMediaService {
  private static remoteIndex: Map<string, string> | null = null;

  private static getRemoteIndex(): Map<string, string> {
    if (!this.remoteIndex) {
      this.remoteIndex = new Map(EXERCISE_VIDEO_MANIFEST.map((e) => [e.id, e.videoUrl]));
    }
    return this.remoteIndex;
  }

  /** Bundled Metro require() asset for one of the 12 core exercises, if any. */
  private static getBundledSource(mediaKey?: ExerciseMediaKey): number | null {
    if (!mediaKey) return null;
    return EXERCISE_VIDEOS[mediaKey] ?? null;
  }

  private static cacheFilePath(libraryId: string): string {
    // Sanitize path segment — library ids are already slug-safe (lib-...).
    const safe = libraryId.replace(/[^a-zA-Z0-9._-]/g, '_');
    return `${CACHE_DIR}${safe}.mp4`;
  }

  private static async ensureCacheDir(): Promise<void> {
    if (!FileSystem.cacheDirectory) return;
    const info = await FileSystem.getInfoAsync(CACHE_DIR);
    if (!info.exists) {
      await FileSystem.makeDirectoryAsync(CACHE_DIR, { intermediates: true });
    }
  }

  /**
   * Returns a playable source for ExerciseVideo's `source` prop.
   * Bundled asset (number) takes priority; otherwise resolves to a remote
   * { uri } immediately (for instant playback) while a background download
   * populates the disk cache for next time.
   */
  static async getPlaybackSource(
    libraryId: string,
    mediaKey?: ExerciseMediaKey
  ): Promise<{ uri: string } | number | null> {
    const bundled = this.getBundledSource(mediaKey);
    if (bundled != null) return bundled;

    if (!FileSystem.cacheDirectory) {
      const remoteUrl = this.getRemoteIndex().get(libraryId);
      return remoteUrl ? { uri: remoteUrl } : null;
    }

    await this.ensureCacheDir();
    const cachePath = this.cacheFilePath(libraryId);
    const cacheInfo = await FileSystem.getInfoAsync(cachePath);
    if (cacheInfo.exists) {
      return { uri: cachePath };
    }

    const remoteUrl = this.getRemoteIndex().get(libraryId);
    if (!remoteUrl) return null;

    void this.downloadAndCacheInBackground(remoteUrl, cachePath);
    return { uri: remoteUrl };
  }

  private static async downloadAndCacheInBackground(
    remoteUrl: string,
    targetPath: string
  ): Promise<void> {
    try {
      const result = await FileSystem.downloadAsync(remoteUrl, targetPath);
      if (result.status !== 200) {
        await FileSystem.deleteAsync(targetPath, { idempotent: true });
        return;
      }
      await this.evictIfOverBudget();
    } catch {
      // Background failure must never surface to the player — it already
      // has a working remote URL for direct playback.
      await FileSystem.deleteAsync(targetPath, { idempotent: true }).catch(() => {});
    }
  }

  private static async evictIfOverBudget(): Promise<void> {
    await this.ensureCacheDir();
    const files = await FileSystem.readDirectoryAsync(CACHE_DIR);
    const entries: CacheEntry[] = [];
    let totalBytes = 0;

    for (const file of files) {
      const fullPath = `${CACHE_DIR}${file}`;
      const info = await FileSystem.getInfoAsync(fullPath);
      if (!info.exists || info.isDirectory) continue;
      const sizeBytes = 'size' in info && typeof info.size === 'number' ? info.size : 0;
      totalBytes += sizeBytes;
      const mod =
        'modificationTime' in info && typeof info.modificationTime === 'number'
          ? info.modificationTime * 1000
          : 0;
      entries.push({
        path: fullPath,
        sizeBytes,
        lastAccessedMs: mod
      });
    }

    if (totalBytes <= MAX_CACHE_BYTES) return;

    entries.sort((a, b) => a.lastAccessedMs - b.lastAccessedMs); // oldest first
    for (const entry of entries) {
      if (totalBytes <= MAX_CACHE_BYTES) break;
      await FileSystem.deleteAsync(entry.path, { idempotent: true }).catch(() => {});
      totalBytes -= entry.sizeBytes;
    }
  }

  /** Total bytes currently cached — for a future "Clear video cache" settings action. */
  static async getCacheSizeBytes(): Promise<number> {
    if (!FileSystem.cacheDirectory) return 0;
    await this.ensureCacheDir();
    const files = await FileSystem.readDirectoryAsync(CACHE_DIR);
    let total = 0;
    for (const file of files) {
      const info = await FileSystem.getInfoAsync(`${CACHE_DIR}${file}`);
      if (info.exists && !info.isDirectory && 'size' in info && typeof info.size === 'number') {
        total += info.size;
      }
    }
    return total;
  }

  static async clearCache(): Promise<void> {
    if (!FileSystem.cacheDirectory) return;
    await FileSystem.deleteAsync(CACHE_DIR, { idempotent: true });
    await this.ensureCacheDir();
  }
}
